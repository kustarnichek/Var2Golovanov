﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Var2Golovanov.ModelEF;

namespace Var2Golovanov
{
    public partial class Registration : Form
    {
        Model1 db = new Model1();
        public Registration()
        {
            InitializeComponent();
        }

        private void Registration_Load(object sender, EventArgs e)
        {

        }

        private void RegistrBtn_Click(object sender, EventArgs e)
        {
            if (LoginTxt.Text == "" || PasswordTxt.Text == "" ||
      Password2Txt.Text == "" || NameTxt.Text == "" || RoleTxt.Text == "")
            {
                MessageBox.Show("Нужно задать все данные!");
                return;
            }
            if (PasswordTxt.Text != Password2Txt.Text)
            {
                MessageBox.Show("Значения паролей не совпадают!");
                return;
            }
            if ((RoleTxt.Text != "Покупатель") && (RoleTxt.Text != "Продавец") && (RoleTxt.Text != "Менеджер"))
            {
                MessageBox.Show("Задана неверная роль!");
                return;
            }

            // ищем запись пользователя с введенным логином
            Пользователи usr = db.Пользователи.Find(LoginTxt.Text);
            // если такой пользователь есть и его пароль правильный
            if (usr != null)
            {
                MessageBox.Show("Пользователь с таким логином уже есть!");
                return;
            }
            // создаем нового пользователя
            usr = new Пользователи();
            usr.Логин = LoginTxt.Text;
            usr.Пароль = PasswordTxt.Text;
            usr.Роль = RoleTxt.Text;
            usr.Имя = NameTxt.Text;
            var date1 = new DateTime(2000, 1, 1);
            usr.ДатаРождения = date1;
            usr.Фамилия = "Головин";
            usr.Отчество = "Эдуардович";
            usr.НомерТелефона = "+79999999999";
            usr.ЭлектронныйАдрес = "vitalik@mail.ru";
            usr.Фото = "нет";
            // добавляем новую учетную запись в коллекцию
            db.Пользователи.Add(usr);
            try
            {
                // сохраняем нового пользователя в базе данных
                db.SaveChanges();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return;
            }
            MessageBox.Show("Пользователь " + usr.Логин + " зарегистрирован!");
            Authorization authorization = new Authorization();
            authorization.Show();
            this.Close();
            return;
        }

        private void ExitBtn_Click(object sender, EventArgs e)
        {
            Authorization authorization = new Authorization();
            this.Hide();
            authorization.Show();
        }
    }
}
