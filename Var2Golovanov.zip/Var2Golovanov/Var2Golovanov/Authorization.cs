﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Var2Golovanov.ModelEF;

namespace Var2Golovanov
{
    public partial class Authorization : Form
    {
        public static Пользователи USER { get; set; }
        Model1 db = new Model1();
        public Authorization()
        {
            InitializeComponent();
        }

        private void Authorization_Load(object sender, EventArgs e)
        {

        }

        private void NextBtn_Click(object sender, EventArgs e)
        {
            // проверяем, что в текстовые поля введены данные
            if (LoginTxt.Text == "" || PasswordTxt.Text == "")
            {
                MessageBox.Show("Нужно задать логин и пароль!");
                return;
            }
            // ищем запись пользователя с введенным логином
            Пользователи usr = db.Пользователи.Find(LoginTxt.Text);

            // если такой пользователь есть и его пароль совпадает с введенным
            if ((usr != null) && (usr.Пароль == PasswordTxt.Text))
            {
                USER = usr;
                label4.Visible = true;
                label5.Visible = true;
                label6.Visible = true;
                CPHTxt.Visible = true;
                CPHBtn.Visible = true;
                Random random = new Random();
                label5.Text = random.Next(1, 101).ToString();
            }
            else
            {
                // если данные введены не правильно, то показываем сообщение
                MessageBox.Show("Пользователя с таким логином и паролем нет!");
                return;
            }
        }

        private void CPHBtn_Click(object sender, EventArgs e)
        {
            if (CPHTxt.Text == label5.Text)
            {
                Пользователи usr = db.Пользователи.Find(LoginTxt.Text);
                // сохраняем данные пользователя в статической переменной
                // для использования данных пользователя в других формах
                USER = usr;

                // проверяем роль пользователя
                // если роль = «Директор», то вызываем форму Директора
                if (usr.Роль == "Покупатель")
                {
                    // создаем форму директора
                    Book frm = new Book();
                    // показываем форму директора
                    frm.Show();
                    //  форму подключения скрываем (но не закрываем!)
                    this.Hide();
                }
                // если роль = «Менеджер», то вызываем форму Менеджера
                else if (usr.Роль == "Менеджер")
                {
                    // создаем форму менеджера
                    Books frm = new Books();
                    // показываем форму менеджера
                    frm.Show();
                    // начальную форму подключения скрываем (но не закрываем!)
                    this.Hide();
                }
                else if (usr.Роль == "Продавец")
                {
                    // создаем форму администратора
                    Order frm = new Order();
                    // показываем форму администратора
                    frm.Show();
                    // начальную форму подключения скрываем (но не закрываем!)
                    this.Hide();
                }
                else // если такой роли нет
                {
                    // если данные введены не правильно, то показываем сообщение
                    MessageBox.Show($"Роли {usr.Роль} в системе нет!");
                    return;
                }
            }
            else
            {
                MessageBox.Show("Неверно введено число с картинки!");
                Random random = new Random();
                label5.Text = random.Next(1, 101).ToString();
            }
        }

        private void RegistrBtn_Click(object sender, EventArgs e)
        {
            Registration registration = new Registration();
            this.Hide();
            registration.Show();
        }

        private void ExitBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
